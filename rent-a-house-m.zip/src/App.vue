<template>
  <div>
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App',
  created () { },
  data () {
    return {}
  },
  methods: {},
  computed: {},
  watch: {},
  filters: {},
  components: {}
}
</script>

<style scoped lang='less'>
</style>
