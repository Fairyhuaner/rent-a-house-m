<template>
  <div class="information-page">
    <h3>资讯</h3>
  </div>
</template>

<script>
export default {
  name: 'InformationPage',
  created () { },
  data () {
    return {}
  },
  methods: {},
  computed: {},
  watch: {},
  filters: {},
  components: {}
}
</script>

<style scoped lang='less'>
</style>
